#' learnstats: Using R as an interactive educational environment.
#'
#'
#' @docType package
#' @name stats250
NULL

#' @import RcmdrPlugin.epack
NULL

#' @import ggplot2
NULL
