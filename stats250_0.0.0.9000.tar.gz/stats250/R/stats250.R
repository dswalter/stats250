#' stats250: A package of Helper Functions for STATS 250, the
#' Introductory Statistics class at the University of Michigan.
#'
#'
#' @docType package
#' @name stats250
NULL

#' @import Rcmdr
NULL

#' @import ggplot2
NULL
