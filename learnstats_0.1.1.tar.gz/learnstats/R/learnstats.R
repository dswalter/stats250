#' learnstats: Using R as an interactive educational environment.
#'
#'
#' @docType package
#' @name stats250
NULL

#' @import ggplot2
NULL
